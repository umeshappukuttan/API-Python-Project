from behave import Step


request_headers = {}
response_codes = {}
response_texts = {}
apimethod = {}


@Step("I set sample REST API url")
def create_product_api_endpoint(context):
    global api_url
    api_url = context.base_url


@Step("I Set HEADER param request content type as '{header_content_type}' and accept as '{header_accept}'")
def post_api_endpoint_header_content_type(context, header_content_type, header_accept):
    request_headers['Content-Type'] = header_content_type
    request_headers['Accept'] = header_accept


@Step("Response BODY '{request_name}' is non-empty")
def verify_response_is_not_empty(context, request_name):
    assert response_texts is not None


@Step("Response BODY {'GET'} is non-empty")
def step_impl(context,request_name):
    assert response_texts[request_name] is not None


@Step("I receive valid '{apimethod}' HTTP response code '{respcode}'")
def validate_response_code(context, apimethod, respcode):
    assert context.response.status_code == int(respcode)