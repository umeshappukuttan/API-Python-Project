import requests
import json
from behave import Step

api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}
response_id = {}
api_url = None


# START POST Scenario
@Step("I Set POST posts api endpoint")
def post_api_endpoint_initialisation(context):
    api_endpoints['POST_URL'] = context.base_url + context.create_product_url


@Step("Set request Body")
def create_booking_catalogue_payload_setup(context):
    request_bodies['POST'] = {
  "id": "PRDA001",
  "name": "JackFruit",
  "description": "Organic JackFruit",
  "price": 99,
  "itemCount": 15,
  "Active": True
}


@Step("Send a POST HTTP request")
def create_booking_catalogue_response_extraction(context):
    global prdid
    # sending get request and saving response as response object
    context.response = requests.post(url=api_endpoints['POST_URL'], json=request_bodies['POST'], headers={
        "Content-Type": "application/json", "Accept": "application/json"})
    if context.response.status_code == 200:
        prdid = context.response.json()['id']
        context.prdid = prdid
    response_texts['POST'] = context.response.text
    # extracting response status_code
    statuscode = context.response.status_code
    response_codes['POST'] = statuscode


@Step("Set request Body with blank name")
def create_booking_catalogue_payload_setup(context):
    print(prdid)
    request_bodies['POST'] = {
  "id": "P002",
  "name": "",
  "description": "Banana",
  "price": 10,
  "itemCount": 100,
  "Active": True
}


# END Create Product Scenario
