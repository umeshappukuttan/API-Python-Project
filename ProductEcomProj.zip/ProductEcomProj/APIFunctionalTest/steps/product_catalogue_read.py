import requests
from behave import Step
import json


api_endpoints = {}
request_headers = {}
response_codes = {}
response_texts = {}
request_bodies = {}


@Step("I Set GET api endpoint")
def step_impl(context):
    id = context.prdid
    api_endpoints['GET_URL'] = context.base_url + context.get_all_products_url + "/" + id


@Step("Send GET HTTP request")
def step_impl(context):
    # sending get request and saving response as response object
    context.response = requests.get(url=api_endpoints['GET_URL'], headers={
        "Content-Type": "application/json", "Accept": "application/json"})
    # extracting response text
    response_texts['GET']=context.response.text
    # extracting response status_code
    context.statuscode = context.response.status_code
    response_codes['GET'] = context.statuscode


# END GET Scenario
