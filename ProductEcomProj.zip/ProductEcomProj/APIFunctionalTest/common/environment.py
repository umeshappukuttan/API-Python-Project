# This class is executed before any Behave code
import json
import os


def before_all(context):
    # This function executed before any Behave code
    # Read config file and set the values
    test_config_file = os.environ['CONFIG_FILE'] if 'TEST_CONFIG_FILE' in os.environ else 'config/CONFIG_FILE.json'
    with open(test_config_file) as data_file:
        config = json.load(data_file)
        context.create_product_url = config['create_product_url']
        context.delete_by_id_url = config['delete_by_id_url']
        context.update_product_url = config['update_product_url']
        context.get_product_by_id_url = config['get_product_by_id_url']
        context.get_all_products_url = config['get_all_products_url']
        context.base_url = config['base_url']





