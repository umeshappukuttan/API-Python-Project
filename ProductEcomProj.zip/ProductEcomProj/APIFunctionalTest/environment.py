from common.environment import *

# environment.py file specific to this project pulls in from the common.environment.py