Download the python automation code from the git repo "ProductEcomProj.zip" 
Use python editor like pycharm and load the project 
Ensure the PrdEcommApiProjConfig is having following configuration: 
Script path: C:\gitworkspace\ProductEcomProj\venv\Lib\site-packages\behave\__main__.py 
Working directory: C:\gitworkspace\ProductEcomProj\APIFunctionalTest
Under Setting, ensure Python Interpreter having following packages installed
 a. behave
 b. jsonpath
 c. requests

Run the automation from feature module [ ALl feature will be executed ] Ensured no print statement in the code